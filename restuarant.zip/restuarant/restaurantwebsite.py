import tkinter as tk
from tkinter import messagebox

root = tk.Tk()
root.title("Restaurant Management System")
root.geometry("800x600")
root.config(bg="lightyellow")

# ----------------------------
# Menu Prices
# ----------------------------
menu = {
    "Burger": 120,
    "Pizza": 250,
    "Pasta": 180,
    "Sandwich": 100,
    "Drinks": 60
}

# ----------------------------
# Tkinter Variables
# ----------------------------
vars = {}
entries = {}
total_var = tk.StringVar()
tax_var = tk.StringVar()
final_total_var = tk.StringVar()
receipt_var = tk.StringVar()

# ----------------------------
# Functions
# ----------------------------
def calculate_total():
    total = 0
    receipt = "====== Receipt ======\n"
    for item, price in menu.items():
        qty = vars[item].get()
        if qty:
            cost = int(qty) * price
            total += cost
            receipt += f"{item} x {qty} = ₹{cost}\n"
    tax = total * 0.05
    final = total + tax

    total_var.set(f"₹{total:.2f}")
    tax_var.set(f"₹{tax:.2f}")
    final_total_var.set(f"₹{final:.2f}")
    receipt += f"\nSubtotal: ₹{total:.2f}"
    receipt += f"\nTax (5%): ₹{tax:.2f}"
    receipt += f"\nTotal: ₹{final:.2f}"
    receipt_var.set(receipt)

def reset_all():
    for var in vars.values():
        var.set("")
    total_var.set("")
    tax_var.set("")
    final_total_var.set("")
    receipt_var.set("")

def exit_app():
    if messagebox.askyesno("Exit", "Do you really want to exit?"):
        root.destroy()

# ----------------------------
# UI Layout
# ----------------------------

title = tk.Label(root, text="Restaurant Ordering System", font=("Arial", 24, "bold"), bg="lightyellow", fg="darkred")
title.pack(pady=10)

frame_menu = tk.Frame(root, bg="lightyellow")
frame_menu.pack(pady=10)

tk.Label(frame_menu, text="Item", font=("Arial", 16, "bold"), bg="lightyellow").grid(row=0, column=0, padx=10)
tk.Label(frame_menu, text="Quantity", font=("Arial", 16, "bold"), bg="lightyellow").grid(row=0, column=1, padx=10)

# Generate entry rows
for i, (item, price) in enumerate(menu.items()):
    tk.Label(frame_menu, text=f"{item} (₹{price})", font=("Arial", 14), bg="lightyellow").grid(row=i+1, column=0, padx=10, sticky="w")
    vars[item] = tk.StringVar()
    entries[item] = tk.Entry(frame_menu, textvariable=vars[item], width=10)
    entries[item].grid(row=i+1, column=1)

# ----------------------------
# Summary Section
# ----------------------------
frame_summary = tk.Frame(root, bg="lightyellow")
frame_summary.pack(pady=10)

tk.Label(frame_summary, text="Subtotal:", font=("Arial", 14), bg="lightyellow").grid(row=0, column=0, sticky="e")
tk.Label(frame_summary, textvariable=total_var, font=("Arial", 14), bg="lightyellow", fg="blue").grid(row=0, column=1, sticky="w")

tk.Label(frame_summary, text="Tax (5%):", font=("Arial", 14), bg="lightyellow").grid(row=1, column=0, sticky="e")
tk.Label(frame_summary, textvariable=tax_var, font=("Arial", 14), bg="lightyellow", fg="blue").grid(row=1, column=1, sticky="w")

tk.Label(frame_summary, text="Total:", font=("Arial", 14, "bold"), bg="lightyellow").grid(row=2, column=0, sticky="e")
tk.Label(frame_summary, textvariable=final_total_var, font=("Arial", 14, "bold"), bg="lightyellow", fg="darkgreen").grid(row=2, column=1, sticky="w")

# ----------------------------
# Buttons
# ----------------------------
frame_buttons = tk.Frame(root, bg="lightyellow")
frame_buttons.pack(pady=15)

tk.Button(frame_buttons, text="Calculate", font=("Arial", 14), bg="lightgreen", command=calculate_total).grid(row=0, column=0, padx=10)
tk.Button(frame_buttons, text="Reset", font=("Arial", 14), bg="orange", command=reset_all).grid(row=0, column=1, padx=10)
tk.Button(frame_buttons, text="Exit", font=("Arial", 14), bg="red", fg="white", command=exit_app).grid(row=0, column=2, padx=10)

# ----------------------------
# Receipt
# ----------------------------
frame_receipt = tk.Frame(root, bg="lightyellow")
frame_receipt.pack(pady=10)

tk.Label(frame_receipt, text="Receipt", font=("Arial", 16, "bold"), bg="lightyellow").pack()
receipt_text = tk.Text(frame_receipt, height=10, width=60, font=("Courier", 12))
receipt_text.pack()
receipt_text.config(state="disabled")

def update_receipt():
    receipt_text.config(state="normal")
    receipt_text.delete("1.0", tk.END)
    receipt_text.insert(tk.END, receipt_var.get())
    receipt_text.config(state="disabled")

# Update receipt after calculation
receipt_var.trace("w", lambda *args: update_receipt())

# ----------------------------
# Mainloop
# ----------------------------
root.mainloop()
s
s
